import numpy as np
import pandas as pd
import models as m
import data
from sklearn.model_selection import KFold
from sklearn.utils._testing import ignore_warnings
from sklearn.exceptions import ConvergenceWarning


# Splits data into 10 pieces, one being test set and the remaining 9 being training sets
def foldData(X, y):

    foldedData = KFold(n_splits=10, shuffle=True)    
    return foldedData.split(X, y)


# Using the data_folds, tests are run on each of the folds using the provided model to 
# determine its average accuracy. Then prints the accuracy as well as the stacked model accuracy
# Ignoring converge warnings because multi-layer perceptron produced many of them but still seems to work
@ignore_warnings(category=ConvergenceWarning)
def train(X, y, data_folds, model, model_name):
    
    # acc_averages = 0
    
    accuracy_list = []

    for train_subset, test_subset in data_folds:

        # Save the info
        X_train, X_test = X[train_subset], X[test_subset]
        y_train, y_test = y[train_subset], y[test_subset]

        # Run the model and save its resulting labels
        label_list = model(X_train, X_test, y_train)

        # Check accuracy of the model results
        correctly_labeled = np.array(np.where(y_test == label_list))
        accuracy = correctly_labeled[0].shape[0] / y_test.shape[0]
        accuracy_list.append(accuracy)

    # Print the accuracy for the model
    accuracy_list = np.array(accuracy_list)
    print(f'{model_name}: {np.mean(accuracy_list)}')
    

def main():

    # Get Training Data File 
    trainFile = pd.read_csv('TrainOnMe.csv', usecols=range(1,15))

    # Clean Training Data
    X, y = data.cleanData(trainFile)

    # Get Evaluation Data File
    evalFile = pd.read_csv('EvaluateOnMe.csv', usecols=range(1,14))

    # Final Classifier 
    X_eval = data.clean_Eval_Data(evalFile)    
    final_labels = m.final_classifier(X, X_eval, y)

    # Create txt file and write the predicted labels there
    output_file = open("QDAPredictions.txt", "w")        
    for label in final_labels:
        output_file.write(f'{label}\n')
    print("Finished Writing!")
    

if __name__ == "__main__":
    main()