import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, StackingClassifier
from sklearn.naive_bayes import GaussianNB

# Final model used was Quadratic Discriminant Analysis. 
# Stacking model used earlier performed almost the same but QDA showed a 0.1% better accuracy.
# Wouldn't be surprised if stacking would be better on final data

def final_classifier(X_train, X_test, y_train):    
    
    model = QuadraticDiscriminantAnalysis()
    model.fit(X_train, y_train)
    label_list = model.predict(X_test)
    return label_list


